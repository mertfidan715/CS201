#ifndef __MOVIE_H
#define __MOVIE_H
#include <string>
using namespace std;

class movie{
public:
    movie();
    movie(int id, bool returned);
    int getId();
    void setId(int id);
    bool getReturned();
    void setReturned(bool returned);
    int movieId;
    bool isReturned;
};
#endif
