#include <string>
#include "SLL.h"
#include "movie.h"
using namespace std;

class subscriber{
public:
    subscriber();
    ~subscriber();
    subscriber(int id);
    void setId(int id);
    int getId();
    SLL<movie>* getTransactions();//check if this is true
    Node<movie>* getTransactionsHead();
    int subscriberId = 0;
    SLL<movie>* transactions;
};
