#include "Node.h"
#include "movie.h"
#include "subscriber.h"
#define NULL __null
using namespace std;

template<class ItemType>
Node<ItemType>::Node(){
    nextPtr = nullptr;
}

template<class ItemType>
Node<ItemType>::Node(const ItemType& itemEntry, int idEntry){
    item = itemEntry;
    id = idEntry;
    nextPtr = nullptr;
}

template<class ItemType>
Node<ItemType>::Node(const ItemType& itemEntry, Node<ItemType>* nextPtrEntry){
    item = itemEntry;
    nextPtr = nextPtrEntry;
}

template<class ItemType>
void Node<ItemType>::setItem(const ItemType& itemEntry){
    item = itemEntry;
}

template<class ItemType>
void Node<ItemType>::setNext(Node<ItemType>* nextPtrEntry){
    nextPtr = nextPtrEntry;
}

template<class ItemType>
ItemType Node<ItemType>::getItem() const{
    return item;
}

template<class ItemType>
int Node<ItemType>::getId() const{
    return id;
}

template<class ItemType>
Node<ItemType>* Node<ItemType>::getNext() const{
    return nextPtr;
}
template class Node<movie>;
template class Node<subscriber>;
