#include "SLL.h"
#include "movie.h"
#include "subscriber.h"
#include <iostream>
template<class ItemType>//default ctor
SLL<ItemType>::SLL(){
    headPtr = nullptr;
    itemNo = 0;
}

template<class ItemType> //copy ctor
SLL<ItemType>::SLL(SLL<ItemType>& original){
    itemNo = original.itemNo;
    Node<ItemType>* origPtr = original.headPtr;
    if(origPtr == nullptr){
        headPtr = nullptr;
    }
    else{
        headPtr = new Node<ItemType>(origPtr->item, origPtr->id);
        Node<ItemType>* copiedPtr = headPtr;
        origPtr = origPtr->getNext();
        while(origPtr != nullptr){
            Node<ItemType>* newNodePtr = new Node<ItemType>(origPtr->getItem(), origPtr->getId());
            copiedPtr->setNext(newNodePtr);
            origPtr = origPtr->getNext();
            copiedPtr = copiedPtr->getNext();
        }
        copiedPtr->setNext(nullptr);
    }
}

template<class ItemType> //destructor
SLL<ItemType>::~SLL(){
    clearList();
}

template<class ItemType>
bool SLL<ItemType>::isEmpty() const{
    if(itemNo == 0){return true;}
    else {return false;}
}

template<class ItemType>
int SLL<ItemType>::getLength() const{
    return itemNo;
}

template<class ItemType>
Node<ItemType>* SLL<ItemType>::getNodeAt(int location) const{
    Node<ItemType>* curPtr = headPtr;
    for(int i = 1; i <= itemNo; i++){
        if(location == i){
            return curPtr;
        }
        curPtr = curPtr->nextPtr;
    }
}

template<class ItemType>
void SLL<ItemType>::insertItem(int id, const ItemType& entry){
    if(headPtr == nullptr){
        Node<ItemType>* newPtr = new Node<ItemType>(entry, id);
        newPtr->setNext(nullptr);
        headPtr = newPtr;
    }
    else{
        Node<ItemType>* curPtr = headPtr;
        Node<ItemType>* newPtr = new Node<ItemType>(entry, id);
        if(id < curPtr->getId()){//entry has the smallest id
            newPtr->setNext(curPtr);
            headPtr = newPtr;
        }
        else{
            while(curPtr != nullptr){
                if(curPtr->nextPtr == nullptr){
                    curPtr->setNext(newPtr);
                    newPtr->setNext(nullptr);
                    break;
                }
                else if(id < (curPtr->nextPtr->id)){
                    newPtr->setNext(curPtr->getNext());
                    curPtr->setNext(newPtr);
                    break;
                }
                curPtr = curPtr->nextPtr;
            }
        }
    }
    itemNo++;
}

template<class ItemType>
void SLL<ItemType>::removeItem(int location){
    Node<ItemType>* curPtr = nullptr;
    if(location == 1){
        curPtr = headPtr;
        headPtr = headPtr->nextPtr;
    }
    else{
        curPtr = getNodeAt(location);
        Node<ItemType>* prevPtr = getNodeAt(location-1);
        prevPtr->setNext(curPtr->nextPtr);
    }
    curPtr->setNext(nullptr);
    delete curPtr;
    curPtr = nullptr;
    itemNo--;
}

template<class ItemType>
void SLL<ItemType>::clearList(){
    Node<ItemType>* curPtr = headPtr;
    if(itemNo == 0){
        return;
    }
    else{
        while(curPtr != nullptr){
            curPtr = curPtr->nextPtr;
            removeItem(1);
        }
        itemNo = 0;
    }
}
template class SLL<movie>;
template class SLL<subscriber>;

