#include "movie.h"

movie::movie(){
    movieId = 0;
    isReturned = true;
}

movie::movie(int id, bool returned){
    movieId = id;
    isReturned = returned;
}

int movie::getId(){
    return movieId;
}

void movie::setId(int id){
    movieId = id;
}

bool movie::getReturned(){
    return isReturned;
}

void movie::setReturned(bool returned){
    isReturned = returned;
}
