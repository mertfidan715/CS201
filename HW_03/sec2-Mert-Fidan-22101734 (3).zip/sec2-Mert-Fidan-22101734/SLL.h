#ifndef __SLL_H
#define __SLL_H
#include "Node.h"
using namespace std;

template<class ItemType>
class SLL{
public:
    SLL();
    SLL(SLL<ItemType>& sll);
    virtual ~SLL();
    bool isEmpty() const;
    int getLength() const;
    void insertItem(int id, const ItemType& entry);
    void removeItem(int location);
    void clearList();
    int itemNo;
    Node<ItemType>* headPtr;
private:
    Node<ItemType>* getNodeAt(int location) const;
};
#endif
