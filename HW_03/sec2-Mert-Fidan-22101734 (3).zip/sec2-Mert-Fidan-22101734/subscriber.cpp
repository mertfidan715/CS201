#include "subscriber.h"

subscriber::subscriber(){
    subscriberId = 0;
    transactions = new SLL<movie>;
}

subscriber::~subscriber(){
    subscriberId = 0;
    transactions->clearList();
}

subscriber::subscriber(int id){
    subscriberId = id;
    transactions = new SLL<movie>;
}

void subscriber::setId(int id){
    subscriberId = id;
}

int subscriber::getId(){
    return subscriberId;
}

SLL<movie>* subscriber::getTransactions(){//check
    return transactions;
}

Node<movie>* subscriber::getTransactionsHead(){
    return transactions->headPtr;
}
