#ifndef __NODE_H
#define __NODE_H
template<class ItemType>
class Node{
public:
    Node();
    Node(const ItemType& itemEntry, int idEntry);
    Node(const ItemType& itemEntry, Node<ItemType>* nextPtrEntry);
    void setItem(const ItemType& itemEntry);
    void setNext(Node<ItemType>* nextPtrEntry);
    void setId(int idEntry);
    int getId() const;
    ItemType getItem() const;
    Node<ItemType>* getNext() const;
    ItemType item;
    int id;
    Node<ItemType>* nextPtr;
};
#endif
