#include <string>
#include <iostream>
#include <fstream>
#include "MovieRentalSystem.h"
#define NULL __null
using namespace std;

MovieRentalSystem::MovieRentalSystem(const string movieInfoFileName, const string subscriberInfoFileName ){
    ifstream myfile;
    bool isMovieFileExisting = false;
    bool isSubscriberFileExisting = false;
    allMovies = new SLL<movie>;
    allSubscribers = new SLL<subscriber>;
    int movieId = 0;
    int movieIdCount = 0;
    myfile.open(movieInfoFileName);
    if(myfile.is_open()){
        isMovieFileExisting = true;
        myfile >> movieTypeCount;
        while( movieCount < movieTypeCount ){
            myfile >> movieId;
            myfile >> movieIdCount;
            for(int i = 1; i <= movieIdCount; i++){
                movie newMovie(movieId, true);
                allMovies->insertItem(movieId, newMovie);
            }
            movieCount++;
        }
    }
    myfile.close();
    myfile.open(subscriberInfoFileName);
    int subscriberId = 0;
    if(myfile.is_open()){
        isSubscriberFileExisting = true;
        myfile >> subscriberTypeCount;
        while(subscriberCount < subscriberTypeCount){
            myfile >> subscriberId;
            subscriber newSubscriber(subscriberId);
            allSubscribers->insertItem(subscriberId, newSubscriber);
            subscriberCount++;
        }
    }
    if(isMovieFileExisting == false){
        cout << "Input file " << movieInfoFileName << " does not exist" << endl;
    }
    else if(isSubscriberFileExisting == false){
        cout << "Input file " << subscriberInfoFileName << " does not exist" << endl;
    }
    else{
        cout << subscriberCount << " subscribers and " << movieTypeCount << " movies have been loaded" << endl;
    }
    myfile.close();
}

MovieRentalSystem::~MovieRentalSystem(){
    allMovies->clearList();
    Node<subscriber>* curPtr = allSubscribers->headPtr;
    subscriber* curSubscriber = &(curPtr->item);
    SLL<movie>* transactions = curSubscriber->transactions;
    while(curPtr != nullptr){
        curSubscriber = &(curPtr->item);
        transactions = curSubscriber->transactions;
        transactions->clearList();
        curPtr = curPtr->nextPtr;
    }
    allSubscribers->clearList();
}

void MovieRentalSystem::addMovie(const int movieId, const int numCopies){
    bool isIdExisting = false;
    Node<movie>* curPtr = allMovies->headPtr;
    while(curPtr != nullptr){
        if(curPtr->id == movieId){
            isIdExisting = true;
        }
        curPtr = curPtr->nextPtr;
    }
    if(isIdExisting == true){
        cout << "Movie " << movieId << " already exists" << endl;
    }
    else{
        for(int i = 0; i < numCopies; i++){
            movie newMovie(movieId, true);
            allMovies->insertItem(movieId, newMovie);
            movieCount++;
        }
        cout << "Movie " << movieId << " has been added" << endl;
    }
}

void MovieRentalSystem::removeMovie(const int movieId){
    bool isMovieExisting = false;
    bool areAllReturned = true;
    Node<movie>* curPtr = allMovies->headPtr;
    movie* curMovie = &(curPtr->item);
    while(curPtr != nullptr){
        curMovie = &(curPtr->item);
        if(curPtr->id == movieId){
            isMovieExisting = true;
            if(curMovie->isReturned == false){
                areAllReturned = false;
            }
        }
        curPtr = curPtr->nextPtr;
    }
    if(isMovieExisting == false){
        cout << "Movie " << movieId << " does not exist" << endl;
    }
    else if(areAllReturned == false){
        cout << "Movie " << movieId << " cannot be removed -- at least one copy has not been returned" << endl;
    }
    else{
        int movieLoc = 1;
        Node<movie>* checkPtr = allMovies->headPtr;
        movie* checkMovie = &(checkPtr->item);
        while(checkPtr != nullptr){
            checkMovie = &(checkPtr->item);
            if(checkMovie->movieId == movieId){
                checkPtr = checkPtr->nextPtr;
                checkMovie = &(checkPtr->item);
                allMovies->removeItem(movieLoc);
                movieCount--;
            }
            else{
                checkPtr = checkPtr->nextPtr;
                movieLoc++;
            }
        }
        cout << "Movie " << movieId << " has been removed" << endl;
    }
}

void MovieRentalSystem::removeSubscriber(const int subscriberId){
    bool isSubscriberExisting = false;
    bool areAllMoviesReturned = true;
    int subscriberLoc = 1;
    Node<subscriber>* curPtr = allSubscribers->headPtr;
    subscriber* curSubscriber = &(curPtr->item);
    while(curPtr != nullptr){
        curSubscriber = &(curPtr->item);
        if(curSubscriber->getId() == subscriberId){
            isSubscriberExisting = true;
            break;
        }
        subscriberLoc++;
        curPtr = curPtr->nextPtr;
    }
    SLL<movie>* transactions = curSubscriber->transactions;//SLL for all transactions
    Node<movie>* movies = transactions->headPtr;//pointer that is equal to the headPtr of the transactions
    movie* curMovie = &(movies->item);
    while(movies != nullptr){
        curMovie = &(movies->item);
        if(curMovie->isReturned == false){
            areAllMoviesReturned = false;
            break;
        }
        movies = movies->nextPtr;
    }
    if(isSubscriberExisting == false){
        cout << "Subscriber " << subscriberId << " does not exist" << endl;
    }
    else if(areAllMoviesReturned == false){
        cout << "Subscriber " << subscriberId << " cannot be removed -- at least one movie has not been returned" << endl;
    }
    else{
        transactions->clearList();
        allSubscribers->removeItem(subscriberLoc);
        subscriberCount--;
        cout << "Subscriber " << subscriberId << " has been removed" << endl;
    }
}

void MovieRentalSystem::rentMovie(const int subscriberId, const int movieId){
    bool isSubscriberExisting = false;
    bool isMovieExisting = false;
    bool isMovieAvailable = false;
    Node<subscriber>* curSubscriberPtr = allSubscribers->headPtr;
    subscriber* curSubscriber = &(curSubscriberPtr->item);
    while(curSubscriberPtr != nullptr){
        curSubscriber = &(curSubscriberPtr->item);
        if(curSubscriber->getId() == subscriberId){
            isSubscriberExisting = true;
            break;
        }
        curSubscriberPtr = curSubscriberPtr->getNext();
    }
    Node<movie>* curMoviePtr = allMovies->headPtr;
    movie* curMovie = &(curMoviePtr->item);
    while(curMoviePtr != nullptr){
        curMovie = &(curMoviePtr->item);
        if(curMovie->movieId == movieId){
            isMovieExisting = true;
            if(curMovie->isReturned == true){
                isMovieAvailable = true;
                break;
            }
        }
        curMoviePtr = curMoviePtr->nextPtr;
    }
    if(isMovieExisting == false && isSubscriberExisting == false){
        cout << "Subscriber " << subscriberId << " and movie " << movieId << " do not exist" << endl;
    }
    else if(isMovieExisting == true && isSubscriberExisting == false){
        cout << "Subscriber " << subscriberId << " does not exist" << endl;
    }
    else if(isMovieExisting == false && isSubscriberExisting == true){
        cout << "Movie " << movieId << " does not exist" << endl;
    }
    else if(isMovieAvailable == false && isMovieExisting == true){
        cout << "Movie " << movieId << " has no available copy for renting" << endl;
    }
    else{
        curMovie->isReturned = false;
        SLL<movie>* transactions = curSubscriber->transactions;
        movie rented(movieId, false);
        transactions->insertItem(movieId, rented);
        cout << "Movie " << movieId << " has been rented by subscriber " << subscriberId << endl;
    }
}

void MovieRentalSystem::returnMovie(const int subscriberId, const int movieId){
    bool isSubscriberExisting = false;
    bool isMovieExisting = false;
    bool isMovieRented = false;
    int subscriberLoc = 1;
    int movieLoc = 1;
    Node<subscriber>* curSubscriberPtr = allSubscribers->headPtr;
    subscriber* curSubscriber = &(curSubscriberPtr->item);
    while(curSubscriberPtr != nullptr){
        curSubscriber = &(curSubscriberPtr->item);
        if(curSubscriber->getId() == subscriberId){
            isSubscriberExisting = true;
            break;
        }
        subscriberLoc++;
        curSubscriberPtr = curSubscriberPtr->getNext();
    }
    Node<movie>* curMoviePtr = allMovies->headPtr;
    movie* curMovie = &(curMoviePtr->item);
    while(curMoviePtr != nullptr){
        curMovie = &(curMoviePtr->item);
        if(curMovie->movieId == movieId){
            isMovieExisting = true;
            break;
        }
        curMoviePtr = curMoviePtr->getNext();
    }
    SLL<movie>* transactions = curSubscriber->transactions;
    Node<movie>* transactionCheckPtr = transactions->headPtr;
    movie* transactionCheckMovie = &(transactionCheckPtr->item);
    while(transactionCheckPtr != nullptr){
        transactionCheckMovie = &(transactionCheckPtr->item);
        if((transactionCheckMovie->movieId == movieId) && (transactionCheckMovie->isReturned == false)){
            isMovieRented = true;
            transactionCheckMovie->isReturned = true;
            break;
        }
        movieLoc++;
        transactionCheckPtr = transactionCheckPtr->nextPtr;
    }
    if(isSubscriberExisting == false){
        cout << "Subscriber " << subscriberId << " does not exist" << endl;
    }
    else if(isMovieExisting == false){
        cout << "Movie " << movieId << " does not exist" << endl;
    }
    else if(isMovieRented == false){
        cout << "No rental transaction for subscriber " << subscriberId << " and movie " << movieId << endl;
    }
    else{
        curMovie->isReturned = true;
        cout << "Movie " << movieId << " has been returned by subscriber " << subscriberId << endl;
    }
}

void MovieRentalSystem::showMoviesRentedBy(const int subscriberId) const{
    bool isSubscriberExisting = false;
    Node<subscriber>* curPtr = allSubscribers->headPtr;
    subscriber* curSubscriber = &(curPtr->item);
    while(curPtr != nullptr){
        curSubscriber = &(curPtr->item);
        if(curSubscriber->getId() == subscriberId){
            isSubscriberExisting = true;
            break;
        }
        curPtr = curPtr->nextPtr;
    }
    if(isSubscriberExisting){
        SLL<movie>* transactions = curSubscriber->transactions;//SLL for all transactions
        Node<movie>* movies = transactions->headPtr;//pointer that is equal to the headPtr of the transactions
        if(movies == nullptr){
            cout << "Subscriber " << subscriberId << " has not rented any movies" << endl;
        }
        else{
            movie* curMovie = &(movies->item);
            cout << "Subscriber " << subscriberId << " has rented the following movies:" << endl;
            while(movies != nullptr){
                curMovie = &(movies->item);
                if(curMovie->isReturned == false){
                    cout << curMovie->movieId << " not returned" << endl;
                }
                else{
                    cout << curMovie->movieId << " returned" << endl;
                }
                movies = movies->nextPtr;
            }
        }
    }
    else{
        cout << "Subscriber " << subscriberId << " does not exist" << endl;
    }
}

void MovieRentalSystem::showSubscribersWhoRentedMovie(const int movieId) const{
    bool isMovieExisting = false;
    bool isMovieRented = false;
    Node<movie>* curMoviePtr = allMovies->headPtr;
    movie* curMovie = &(curMoviePtr->item);
    while(curMoviePtr != nullptr){
        curMovie = &(curMoviePtr->item);
        if(curMovie->movieId == movieId){
            isMovieExisting = true;
            if(curMovie->isReturned == false){
                isMovieRented = true;
            }
        }
        curMoviePtr = curMoviePtr->nextPtr;
    }
    if(isMovieExisting == true){
        if(isMovieRented == false){
            cout << "Movie " << movieId << " has not been rented by any subscriber" << endl;
        }
        else{
            cout << "Movie " << movieId << " has been rented by the following subscribers:" << endl;
            Node<subscriber>* curSubPtr = allSubscribers->headPtr;
            subscriber* curSub = &(curSubPtr->item);
            SLL<movie>* transactions = curSub->transactions;
            Node<movie>* curTransactions = transactions->headPtr;
            movie* curTransactionMovie = &(curTransactions->item);
            while(curSubPtr != nullptr){
                curSub = &(curSubPtr->item);
                transactions = curSub->getTransactions();
                curTransactions = transactions->headPtr;
                curTransactionMovie = &(curTransactions->item);
                while(curTransactions != nullptr){
                    curTransactionMovie = &(curTransactions->item);
                    if(curTransactionMovie->movieId == movieId){
                        if(curTransactionMovie->isReturned == false){
                            cout << curSub->getId() << " not returned" << endl;
                        }
                        else{
                            cout << curSub->getId() << " returned" << endl;
                        }
                    }
                    curTransactions = curTransactions->nextPtr;
                }
                curSubPtr = curSubPtr->nextPtr;
            }
        }
    }
    else{
        cout << "Movie " << movieId << " does not exist" << endl;
    }
}

void MovieRentalSystem::showAllMovies() const{
    Node<movie>* curPtr = allMovies->headPtr;
    movie* curMovie = &(curPtr->item);
    int curCount = 1;
    cout << "Movies in the movie rental system:" << endl;
    while(curPtr != nullptr){
        curMovie = &(curPtr->item);
        Node<movie>* counter = curPtr;
        while((counter->nextPtr != nullptr) && (counter->nextPtr->id == curPtr->id)){
            curCount++;
            counter = counter->nextPtr;
        }
        cout << curMovie->movieId << " " << curCount << endl;
        for(int i = 1; i <= curCount; i++){
            curPtr = curPtr->nextPtr;
        }
        curCount = 1;
    }
}

void MovieRentalSystem::showAllSubscribers() const{
    Node<subscriber>* curPtr = allSubscribers->headPtr;
    subscriber* curSub = &(curPtr->item);
    cout << "Subscribers in the movie rental system:" << endl;
    while(curPtr != nullptr){
        curSub = &(curPtr->item);
        cout << curSub->getId() << endl;
        curPtr = curPtr->nextPtr;
    }
}
