#include "city.h"

city::city(){

}

city::city(const string name){
    cityName = name;
}

city::~city(){
    adjacentCities.clear();
}

void city::addAdjacentCity(const string& adjacentCity){
    adjacentCities.push_back(adjacentCity);
    adjacentCityCount++;
}
