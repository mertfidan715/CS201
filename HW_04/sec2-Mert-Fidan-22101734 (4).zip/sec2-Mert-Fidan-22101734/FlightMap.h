#include <list>
#include <map>
#include <string>
#include "flight.h"
using namespace std;

class FlightMap {
public:
    FlightMap( const string cityFile, const string flightFile );
    ~FlightMap();
    void displayAllCities() const;
    void displayAdjacentCities( const string cityName ) const;
    void displayFlightMap() const;
    void findFlights( const string deptCity, const string destCity );
private:
    vector<city> cities;
    map<string, int> citiesId;
    vector<list<string>> flights;
    vector<flight> flightData;
    vector<bool> isVisited;
    int cityCount = 0;
    int flightCount = 0;
};

