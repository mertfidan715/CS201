#include "city.h"
using namespace std;

class flight{
public:
    flight(string originCity, string destinationCity, int flightId, int flightCost);
    flight();
    string getOriginCity();
    string getDestinationCity();
    int getId();
    int getCost();
    string originCity, destinationCity;
    int flightId, flightCost;
};
