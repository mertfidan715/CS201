#include "flight.h"

 flight::flight(string originCity, string destinationCity, int flightId, int flightCost){
    this->originCity = originCity;
    this->destinationCity = destinationCity;
    this->flightId = flightId;
    this->flightCost = flightCost;
 }

 flight::flight(){
 }

 string flight::getOriginCity(){
    return originCity;
 }

 string flight::getDestinationCity(){
    return destinationCity;
 }

 int flight::getId(){
    return flightId;
 }

 int flight::getCost(){
    return flightCost;
 }
