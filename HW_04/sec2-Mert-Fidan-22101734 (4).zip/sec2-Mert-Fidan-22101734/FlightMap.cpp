#include <vector>
#include <list>
#include <map>
#include <string>
#include <stack>
#include <sstream>
#include <iostream>
#include <fstream>
#include "FlightMap.h"
using namespace std;

FlightMap::FlightMap(const string cityFile, const string flightFile){
    ifstream myfile;
    myfile.open(cityFile.c_str(), ios_base::in);
    string cityName;
    list<string> sortCities;
    if(myfile.is_open()){
        while(getline(myfile, cityName, '\n')){
            sortCities.push_back(cityName);
            cityCount++;
        }
    }
    sortCities.sort();
    for(int i = 0; i < cityCount; i++){
        auto c_front = sortCities.begin();
        std::advance(c_front, i);
        string curCityName = *c_front;
        city newCity(curCityName);
        cities.push_back(newCity);
        isVisited.push_back(false);
        citiesId[curCityName] = i;
    }
    myfile.close();
    myfile.open(flightFile.c_str(), ios_base::in);
    string full;
    vector<string> data;
    int flightId, flightCost;
    if(myfile.is_open()){
        while(getline(myfile, full, '\n')){
            stringstream X(full);
            string T;
            while(getline(X, T, ';')){
                data.push_back(T);
            }
            int curOrigCityId = citiesId[data.at(0)];
            int curDestCityId = citiesId[data.at(1)];
            cities[curOrigCityId].adjacentCities.push_back(cities[curDestCityId].cityName);
            cities[curOrigCityId].adjacentCities.sort();
            cities[curOrigCityId].adjacentCityCount++;
            flightId = stoi(data.at(2));
            flightCost = stoi(data.at(3));
            flight newFlight(cities[curOrigCityId].cityName, cities[curDestCityId].cityName, flightId, flightCost);
            flightData.push_back(newFlight);
            flightCount++;
            data.clear();
        }
        for(city &curCity : cities){
            curCity.isVisited.assign(curCity.adjacentCityCount, false);
        }
        flights.resize(cities.size());
        for(auto &curFlight : flightData){
            int curCityId = citiesId[curFlight.originCity];
            flights[curCityId].push_back(curFlight.destinationCity);
            flights[curCityId].sort();
        }
    }
    myfile.close();
    cout << cityCount << " cities and " << flightCount << " flights have been loaded" << '\n';
}

FlightMap::~FlightMap(){

}

void FlightMap::findFlights(const string depCity, const string destCity){
    cout << "Request is to fly from " << depCity << " to " << destCity << ":" << '\n';
    stack<string> cityStack;
    vector<string> curPath;
    vector<vector<string>> allPaths;
    list<int> sums;
    map<int, int> pathIds;
    cityStack.push(cities[citiesId.at(depCity)].cityName);
    curPath.push_back(cities[citiesId.at(depCity)].cityName);
    int flightCounter = 0;
    while(!cityStack.empty()){
        string topCity = cityStack.top();
        if(topCity == destCity){
            int sum = 0;
            for(int q = 0; q < curPath.size() - 1; q++){
                int dest = q + 1;
                for(int i = 0; i < flightData.size(); i++){
                    if((flightData[i].originCity == curPath[q]) && (flightData[i].destinationCity == curPath[dest])){
                        sum += flightData[i].flightCost;
                    }
                }
            }
            allPaths.push_back(curPath);
            sums.push_back(sum);
            sums.sort();
            pathIds[sum] = flightCounter;
            flightCounter++;
            cityStack.pop();
            curPath.pop_back();
        }
        else{
            while(cities[citiesId[topCity]].curVisitCount != cities[citiesId[topCity]].adjacentCityCount){
                auto a_front = cities[citiesId[topCity]].adjacentCities.begin();
                std::advance(a_front, cities[citiesId[topCity]].curVisitCount);
                string adjCity = *a_front;
                //if curPath contains adjCity -> break;
                //else->execute remaining part of the loop body
                bool isCityInStack = false;
                for(int i = 0; i < curPath.size(); i++){
                    if(curPath[i] == adjCity){
                        isCityInStack = true;
                    }
                }
                if(isCityInStack == true){
                    cities[citiesId[topCity]].isVisited[cities[citiesId[topCity]].curVisitCount] = true;
                    cities[citiesId[topCity]].curVisitCount++;
                    continue;
                }
                else{
                    if((cities[citiesId[topCity]].isVisited[cities[citiesId[topCity]].curVisitCount] == false)){
                        cityStack.push(adjCity);
                        curPath.push_back(adjCity);
                        cities[citiesId[topCity]].isVisited[cities[citiesId[topCity]].curVisitCount] = true;
                        for(int i = 0; i < cities[citiesId[topCity]].adjacentCityCount; i++){
                            auto a_front = cities[citiesId[topCity]].adjacentCities.begin();
                            std::advance(a_front, i);
                            string curAdjCity = *a_front;
                            bool reset = true;
                            for(int m = 0; m < curPath.size(); m++){
                                if(curPath[m] == curAdjCity){
                                    reset = false;
                                }
                            }
                            if(reset == true){
                                for(int q = 0; q < cities[citiesId[curAdjCity]].adjacentCityCount; q++){
                                    cities[citiesId[curAdjCity]].isVisited[q] = false;
                                    cities[citiesId[curAdjCity]].curVisitCount = 0;
                                }
                            }
                        }
                        cities[citiesId[topCity]].curVisitCount++;
                        break;
                    }
                    else{
                        break;
                    }
                }
            }
        }
        if((topCity != destCity) && (cityStack.top() == topCity)){
            cityStack.pop();
            curPath.pop_back();
        }
    }
    if(flightCounter == 0){
        cout << "Sorry. HPAir does not fly from " << depCity << " to " << destCity << "." << '\n';
    }
    else{
        for(int i = 0; i < sums.size(); i++){
            auto sum = sums.begin();
            std::advance(sum, i);
            int pathId = pathIds[*sum];
            vector<string> currentPath = allPaths[pathId];
            for(int q = 0; q < currentPath.size() - 1; q++){
                int dest = q + 1;
                for(int i = 0; i < flightData.size(); i++){
                    if((flightData[i].originCity == currentPath[q]) && (flightData[i].destinationCity == currentPath[dest])){
                        cout << "Flight #" << flightData[i].flightId << " from " << currentPath[q] << " to " << currentPath[dest] << ", Cost: " << flightData[i].flightCost << " TL" << '\n';
                    }
                }
            }
            cout << "Total Cost: " << *sum << " TL" << '\n';
        }
    }
    //in the end, reset every value
    for(int i = 0; i < cityCount; i++){
        for(int q = 0; q < cities[i].adjacentCityCount; q++){
            cities[i].isVisited[q] = false;
        }
        cities[i].curVisitCount = 0;
    }
}

void FlightMap::displayAllCities() const{
    cout << "The list of the cities that HPAir serves is given below:" << '\n';
    for(int i = 0; i < cityCount; i++){
        city curCity = cities[i];
        cout << curCity.cityName << ", ";
    }
    cout << endl;
}

void FlightMap::displayAdjacentCities(const string cityName) const{
    cout << "The cities adjacent to " << cityName << " are:" << '\n' << cityName << " -> ";
    int curCityId = citiesId.at(cityName);
    for(int i = 0; i < cities[curCityId].adjacentCityCount; i++){
        auto a_front = cities[curCityId].adjacentCities.begin();
        std::advance(a_front, i);
        string curAdjCity = *a_front;
        cout << curAdjCity << ", ";
        a_front = cities[curCityId].adjacentCities.begin();
    }
    cout << '\n';
}

void FlightMap::displayFlightMap() const{
    cout << "The whole flight map is given below:" << endl;
    for(int i = 0; i < cityCount; i++){
        cout << cities[i].cityName << " -> ";
        for(int q = 0; q < cities[i].adjacentCityCount; q++){
            auto a_front = flights[i].begin();
            std::advance(a_front, q);
            string curAdjCity = *a_front;
            cout << curAdjCity << ", ";
            a_front = flights[i].begin();
        }
        cout << '\n';
    }
}
