#include <list>
#include <string>
#include <vector>
using namespace std;

class city{
public:
    city(const string name);
    city();
    ~city();
    void addAdjacentCity(const string& adjacentCity);
    int cityId = 0;
    int adjacentCityCount = 0;
    int curVisitCount = 0;
    string cityName;
    list<string> adjacentCities;
    vector<bool> isVisited;
};
