//Mert Fidan, Section - 2, 22101734

#include <string>
using namespace std;

class player{
    public:
        player(string tmNm, const string plyrNm, const int jrsy, const int slry);
        player();
        string* getTeamName();
        string getName() const;
        int getJersey() const;
        int getSalary() const;
    private:
        string name, teamName;
        int jersey, salary;
};
