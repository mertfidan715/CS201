//Mert Fidan, Section - 2, 22101734

#include <string>
using namespace std;
#include "team.h"

team::team(const string nm, const int yr){
    name = nm;
    year = yr;
    players = new player[0];
    totalSalary = 0;
    playerNumber = 0;
}
team::team(){
    players = new player[0];
    totalSalary = 0;
    playerNumber = 0;
}
string team::getName() const{
    return name;
}
int team::getYear() const{
    return year;
}
int* team::getPlayerNumber(){
    return &playerNumber;
}
int* team::getTotalSalary(){
    return &totalSalary;
}
player** team::getPlayers(){
    return &players;
}

