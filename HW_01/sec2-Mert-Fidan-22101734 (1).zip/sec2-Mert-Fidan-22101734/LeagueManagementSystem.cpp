//Mert Fidan, Section - 2, 22101734

#include <iostream>
using namespace std;
#include "LeagueManagementSystem.h"

LeagueManagementSystem::LeagueManagementSystem(){
    allTeams = new team*[0];
}

LeagueManagementSystem::~LeagueManagementSystem(){
}

void LeagueManagementSystem::addTeam(const string name, const int year){
    int check = 0;
    for(int i = 0; i <= teamCount - 1; i++){
        if((*allTeams)[i].getName() == name)
            check++;
        }
    if(check == 0){
        if(teamCount == 0){
            team newTeam(name, year);
            teamCount++;
            delete[] allTeams;
            *allTeams = new team[teamCount];
            (*allTeams)[teamCount - 1] = newTeam;
            cout << "Added team " << name << "." << endl;
        }
        else{
            team newTeam(name, year);
            team* newArr = new team[teamCount + 1];
            for(int q = 0; q <= teamCount - 1; q++){
                newArr[q] = (*allTeams)[q];
            }
            teamCount++;
            newArr[teamCount - 1] = newTeam;
            delete[] *allTeams;
            *allTeams = newArr;
            cout << "Added team " << name << "." << endl;
        }
    }
    else{
        cout << "Cannot add team. Team " << name << " already exists." << endl;
    }
    //if teamName does not exist -> create a new team with no players, add the team to the team array(dynamically allocated) if the team name does not already exist, reallocate the size if needed
    //if teamName already exists -> cout error message
}

void LeagueManagementSystem::removeTeam(const string name){
    int check = 0;
    int location = 0;
    for(int i = 0; i <= teamCount - 1; i++){
        if((*allTeams)[i].getName() == name){
            check++;
            location = i;
        }
    }
    if(check == 1){
        team* newArr = new team[teamCount - 1];
        for(int q = 0; q <= location; q++){
            newArr[q] = (*allTeams)[q];
        }
        //delete the player array of the team
        for(int i = location; i <= teamCount - 2; i++){
            newArr[i] = (*allTeams)[i + 1];
        }
        teamCount--;
        delete[] *allTeams;
        *allTeams = newArr;
        cout << "Removed team " << name << "." << endl;
    }
    else{
        cout << "Cannot remove team. Team " << name << " does not exist." << endl;
    }
    //allocate the team in the array by the name, remove it,
    //check the size in chunks, reallocate the array to the fitting size if needed
}

void LeagueManagementSystem::addPlayer(const string teamName, const string playerName,const int jersey, const int salary){
    int check1 = 0;
    int teamLoc = 0;
    for(int i = 0; i <= teamCount - 1; i++){
        if((*allTeams)[i].getName() == teamName){
            check1++;
            teamLoc = i;
        }
    }
    if(check1 == 0){
        cout << "Cannot add player. Team " << teamName << " does not exist." << endl;
    }
    else{
        int check2 = 0, checkTeamLoc = 0;//checking if the player already exists in another team
        for(int i = 0; i <= teamCount - 1; i++){
            int* playerNo = (*allTeams)[i].getPlayerNumber();
            player** current = (*allTeams)[i].getPlayers();
            for(int q = 0; q <= (*playerNo) - 1; q++){
                if((*current)[q].getName() == playerName){
                    check2++;
                    checkTeamLoc = i;
                }
            }
        }
        if(check2 != 0){
            cout << "Cannot add player. Player " << playerName << " already exists in team " << (*allTeams)[checkTeamLoc].getName() << "." << endl;
        }
        else{
            player** playersInTeam = (*allTeams)[teamLoc].getPlayers();
            int* playerNumber = (*allTeams)[teamLoc].getPlayerNumber();
            int* salaryTotal = (*allTeams)[teamLoc].getTotalSalary();
            int check3 = 0;
            for(int q = 0; q <= ((*playerNumber) - 1); q++){
                if((*playersInTeam)[q].getJersey() == jersey){
                    check3++;
                }
            }
            if(check3 == 0){
                //jersey does not exist, add player
                if((*playerNumber) == 0){
                    player* newArr = new player[1];
                    player newPlayer(teamName, playerName, jersey, salary);
                    newArr[0] = newPlayer;
                    delete[] (*playersInTeam);
                    (*playersInTeam) = newArr;
                    (*playerNumber)++;
                    (*salaryTotal) += salary;
                    cout << "Added player " << playerName << " to team " << teamName << "." << endl;
                }
                else{
                    player newPlayer(teamName, playerName, jersey, salary);
                    player* newArr = new player[(*playerNumber) + 1];
                    for(int i = 0; i <= (*playerNumber) - 1; i++){
                        newArr[i] = (*playersInTeam)[i];
                    }
                    newArr[(*playerNumber)] = newPlayer;
                    (*salaryTotal) += salary;
                    delete[] (*playersInTeam);
                    (*playersInTeam) = newArr;
                    (*playerNumber)++;
                    cout << "Added player " << playerName << " to team " << teamName << "." << endl;
                    //may have to delete playerNumber and playersInTeam to prevent memory leaks
                }
            }
            else{
                cout << "Cannot add player. Jersey number " << jersey << " already exists in team " << teamName << "." <<  endl;
            }
        }
    }
    //check if this team exists
    //  if it exists ->
    //      if jersey number does not exist(check teams player array) - >create the player , add this player to the teams player array(using teamName), change the teams player array to the fitting size
    //      if jersey number exists already -> cout error message
    //  if it does not exist -> cout error message
}

void LeagueManagementSystem::removePlayer(const string teamName, const string playerName){
    int check1 = 0;
    int teamLoc = 0;
    for(int i = 0; i <= teamCount - 1; i++){
        if((*allTeams)[i].getName() == teamName){
            check1++;
            break;
        }
        else{
            teamLoc++;
        }
    }
    if(check1 == 0){
        cout << "Cannot remove player. Team " << teamName << " does not exist." << endl;
    }
    else{
        player** playersInTeam = (*allTeams)[teamLoc].getPlayers();
        int* playerNumber = (*allTeams)[teamLoc].getPlayerNumber();
        int check2 = 0;
        int playerLoc = 0;
        for(int q = 0; q <= ((*playerNumber) - 1); q++){
            if((*playersInTeam)[q].getName() == playerName){
                check2++;
                playerLoc = q;
            }
        }
        if(check2 == 0){
            cout << "Cannot remove player. Player " << playerName << " does not exist." << endl;
        }
        else{
            if((*playerNumber) == 1){
                int* salary = (*allTeams)[teamLoc].getTotalSalary();
                (*salary) -= (*playersInTeam)[playerLoc].getSalary();
                delete[] (*playersInTeam);
                (*playersInTeam) = nullptr;
                (*playerNumber) = 0;

                cout << "Removed player " << playerName << " from team " << teamName << "." << endl;
            }
            else{
                int* salary = (*allTeams)[teamLoc].getTotalSalary();
                (*salary) -= (*playersInTeam)[playerLoc].getSalary();
                player* newArr = new player[(*playerNumber) - 1];
                for(int i = 0; i <= playerLoc - 1; i++){
                    newArr[i] = (*playersInTeam)[i];
                }
                for(int q = playerLoc + 1; q <= (*playerNumber) - 1; q++){
                    newArr[q - 1] = (*playersInTeam)[q];
                }
                delete[] (*playersInTeam);
                (*playersInTeam) = newArr;
                (*playerNumber)--;
                cout << "Removed player " << playerName << " from " << teamName << "." << endl;
            }
        }
    //if the team exists
    //  if the player exists -> allocate the player in the teams player array, remove the player, change the array to the fitting size
    //  if the player DNE -> cout error message
    //if the team DNE -> cout error message
    }
}

void LeagueManagementSystem::transferPlayer(const string playerName,const string departTeamName, const string arriveTeamName){
    int check1 = 0, check2 = 0, departingLoc = 0, arriveLoc = 0;
    for(int i = 0; i <= teamCount - 1; i++){
        if((*allTeams)[i].getName() == departTeamName){
            check1++;
            departingLoc = i;
        }
        else if((*allTeams)[i].getName() == arriveTeamName){
            check2++;
            arriveLoc = i;
        }
    }
    if(check1 == 0){
        cout << "Cannot transfer player. Team " << departTeamName << " does not exist." << endl;
    }
    else if(check2 == 0){
        cout << "Cannot transfer player. Team " << arriveTeamName << " does not exist." << endl;
    }
    else{
        int check3 = 0;
        int playerLoc = 0;
        int* playerNumber = (*allTeams)[departingLoc].getPlayerNumber();
        player** depart = (*allTeams)[departingLoc].getPlayers();
        for(int i = 0; i <= (*playerNumber) - 1; i++){
            if((*depart)[i].getName() == playerName){
                check3++;
                playerLoc = i;
            }
        }
        if(check3 == 0){
            cout << "Cannot transfer player. Player " << playerName << " does not exist." << endl;
        }
        else{
            int check4 = 0;
            player** arrive = (*allTeams)[arriveLoc].getPlayers();
            int* playerNo = (*allTeams)[arriveLoc].getPlayerNumber();
            int jerseyNo = (*depart)[playerLoc].getJersey();
            for(int i = 0; i <= (*playerNo) - 1; i++){
                if((*arrive)[i].getJersey() == jerseyNo){
                    check4++;
                }
            }
            if(check4 != 0){
                cout << "Cannot transfer player. Jersey number " << jerseyNo << " already exists in team " << arriveTeamName << "." << endl;
            }
            else{
                //teams exist, player exists only on departing team, transfer player
                int playerSalary = (*depart)[playerLoc].getSalary();
                int* salaryChangeDepart = (*allTeams)[departingLoc].getTotalSalary();
                int* salaryChangeArrive = (*allTeams)[arriveLoc].getTotalSalary();
                string* teamNameChange = (*depart)[playerLoc].getTeamName();
                player* arrivingTeam = new player[(*playerNo) + 1];
                player* departingTeam = new player[(*playerNumber) - 1];
                (*salaryChangeDepart) -= (*depart)[playerLoc].getSalary();
                (*salaryChangeArrive) += (*depart)[playerLoc].getSalary();
                (*teamNameChange) = arriveTeamName;
                for(int i = 0; i <= (*playerNo) - 1; i++){
                    arrivingTeam[i] = (*arrive)[i];
                }
                arrivingTeam[(*playerNo)] = (*depart)[playerLoc];
                delete[] (*arrive);
                (*arrive) = arrivingTeam;
                (*playerNo)++;
                for(int i = 0; i <= playerLoc - 1; i++){
                    departingTeam[i] = (*depart)[i];
                }
                for(int q = playerLoc + 1; q <= (*playerNumber) - 1; q++){
                    departingTeam[q - 1] = (*depart)[q];
                }
                delete[] (*depart);
                (*depart) = departingTeam;
                (*playerNumber)--;
                cout << "Player " << playerName << " transferred from " << departTeamName << " to " << arriveTeamName << endl;
            }
        }
    }
    //if at least one of the teams DNE -> (run a loop in the all teams array, cout error message and end the loop if one of the teams DNE)
    //if the player DNE in the departing teams player array -> cout error message
    //if the player exists in the departing teams player array
    //  allocate the player in the departing teams array, release the player from that team, change the team of the player, change the departing teams player array, add this player to the arrive team, change the size of arrive teams player array
}

void LeagueManagementSystem::showAllTeams() const{
    cout << "Teams in league management system:" << endl;
    if(teamCount == 0){
        cout << "None" << endl;
    }
    else{
        for(int i = 0; i <= teamCount - 1; i++){
            int* playerNo = (*allTeams)[i].getPlayerNumber();
            int* salaryTotal = (*allTeams)[i].getTotalSalary();
            cout << (*allTeams)[i].getName() << ", " << (*allTeams)[i].getYear() << ", " << (*playerNo) << " players, " << (*salaryTotal) << " TL total salary" << endl;
        }
    }
    //if any team exists -> cout all the teams in all teams array (team name, the year it was founded, the number of players in the roster, and the total salary for these players)
}

void LeagueManagementSystem::showTeam(const string name) const{
    int check = 0;
    int loc = 0;
    for(int i = 0; i <= teamCount - 1; i++){
        if((*allTeams)[i].getName() == name){
            check++;
            i = loc;
        }
    }
    if(check == 0){
        cout << "Team " << name << " does not exist." << endl;
    }
    else{
        int* playerNo = (*allTeams)[loc].getPlayerNumber();
        int* salaryTotal = (*allTeams)[loc].getTotalSalary();
        player** players = (*allTeams)[loc].getPlayers();
        cout << "Team:" << endl << (*allTeams)[loc].getName() << " ," << (*allTeams)[loc].getYear() << ", " << (*playerNo) << " players, " << (*salaryTotal) << " TL total salary" << endl << "Players:" << endl;
        for(int i = 0; i <= (*playerNo) - 1; i++){
            cout << (*players)[i].getName() << ", jersey " << (*players)[i].getJersey() << ", " << (*players)[i].getSalary() << " TL salary" << endl;
        }
    }
    //if the team DNE in all teams array -> cout error message
    //if the team exists
    //  cout name of the team, its founding year, information about the players in its roster, and the total salary for the players
}

void LeagueManagementSystem::showPlayer(const string name) const{
    int check = 0, teamLoc = 0, playerLoc = 0;
    for(int i = 0; i <= teamCount - 1; i++){
        int* playerNo = (*allTeams)[i].getPlayerNumber();
        player** current = (*allTeams)[i].getPlayers();
        for(int q = 0; q <= (*playerNo) - 1; q++){
            if((*current)[q].getName() == name){
                check++;
                playerLoc = q;
                teamLoc = i;
            }
        }
    }
    if(check == 0){
        cout << "Player " << name << " does not exist."<< endl;
    }
    else{
        player** shown = (*allTeams)[teamLoc].getPlayers();
        string* teamName = (*shown)[playerLoc].getTeamName();
        cout << "Player:" << endl;
        cout << (*shown)[playerLoc].getName() << ", jersey " << (*shown)[playerLoc].getJersey() << ", " << (*shown)[playerLoc].getSalary() << " TL salary" << endl;
        cout << "Plays in team " << (*teamName) << "." << endl;
    }
    //if the player DNE in any of the teams player array(loop to check all player arrays) -> cout error message
    //if the player exists -> cout name of the player, the jersey number, salary, and the team the player is currently playing in
}
