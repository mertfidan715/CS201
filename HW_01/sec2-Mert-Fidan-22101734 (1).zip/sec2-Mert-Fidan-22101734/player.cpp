//Mert Fidan, Section - 2, 22101734

#include <string>
using namespace std;
#include "player.h"

player::player(string tmNm, string plyrNm, int jrsy, int slry){
    name = plyrNm;
    teamName = tmNm;
    jersey = jrsy;
    salary = slry;
}
player::player(){
}
string* player::getTeamName(){
    return &teamName;
}
string player::getName()const{
    return name;
}
int player::getJersey()const{
    return jersey;
}
int player::getSalary()const{
    return salary;
}

