//Mert Fidan, Section - 2, 22101734

#include <string>
using namespace std;
#include "player.h"

class team{
    public:
        team(const string nm, const int yr);
        team();
        string getName() const;
        int getYear() const;
        int* getPlayerNumber();
        int* getTotalSalary();
        player** getPlayers();
    private:
        player* players;
        string name;
        int year, playerNumber, totalSalary;
};
