#include <iostream>
#include <ctime>
#include <math.h>
#include "findMedian.h"

//Mert Fidan 22101734 Section-2

int main(){

    int* arr1 = new int[50000];
    int* arr2 = new int[100000];
    int* arr3 = new int[150000];
    int* arr4 = new int[200000];
    int* arr5 = new int[250000];
    int* arr6 = new int[300000];
    int* arr7 = new int[350000];
    int* arr8 = new int[400000];
    int* arr9 = new int[450000];
    int* arr10 = new int[500000];
    int* arr11 = new int[50000];
    int* arr12 = new int[100000];
    int* arr13 = new int[150000];
    int* arr14 = new int[200000];
    int* arr15 = new int[250000];
    int* arr16 = new int[300000];
    int* arr17 = new int[350000];
    int* arr18 = new int[400000];
    int* arr19 = new int[450000];
    int* arr20 = new int[500000];
    int* arr21 = new int[50000];
    int* arr22 = new int[100000];
    int* arr23 = new int[150000];
    int* arr24 = new int[200000];
    int* arr25 = new int[250000];
    int* arr26 = new int[300000];
    int* arr27 = new int[350000];
    int* arr28 = new int[400000];
    int* arr29 = new int[450000];
    int* arr30 = new int[500000];

    int sizes[] = {50000, 100000, 150000, 200000, 250000, 300000, 350000, 400000, 450000, 500000, 50000, 100000, 150000, 200000, 250000, 300000, 350000, 400000, 450000, 500000, 50000, 100000, 150000, 200000, 250000, 300000, 350000, 400000, 450000, 500000};
    int** arr = new int*[30];
    arr[0] = arr1;
    arr[1] = arr2;
    arr[2] = arr3;
    arr[3] = arr4;
    arr[4] = arr5;
    arr[5] = arr6;
    arr[6] = arr7;
    arr[7] = arr8;
    arr[8] = arr9;
    arr[9] = arr10;
    arr[10] = arr11;
    arr[11] = arr12;
    arr[12] = arr13;
    arr[13] = arr14;
    arr[14] = arr15;
    arr[15] = arr16;
    arr[16] = arr17;
    arr[17] = arr18;
    arr[18] = arr19;
    arr[19] = arr20;
    arr[20] = arr21;
    arr[21] = arr22;
    arr[22] = arr23;
    arr[23] = arr24;
    arr[24] = arr25;
    arr[25] = arr26;
    arr[26] = arr27;
    arr[27] = arr28;
    arr[28] = arr29;
    arr[29] = arr30;

    srand((unsigned) time(NULL));
    for(int i = 0; i < 50000; i++){
        int n = (rand() % 1000);
        arr1[i] = n;
        arr11[i] = n;
        arr21[i] = n;
    }
    for(int i = 0; i < 100000; i++){
        int n = (rand() % 1000);
        arr2[i] = n;
        arr12[i] = n;
        arr22[i] = n;
    }
    for(int i = 0; i < 150000; i++){
        int n = (rand() % 1000);
        arr3[i] = n;
        arr13[i] = n;
        arr23[i] = n;
    }
    for(int i = 0; i < 200000; i++){
        int n = (rand() % 1000);
        arr4[i] = n;
        arr14[i] = n;
        arr24[i] = n;
    }
    for(int i = 0; i < 250000; i++){
        int n = (rand() % 1000);
        arr5[i] = n;
        arr15[i] = n;
        arr25[i] = n;
    }
    for(int i = 0; i < 300000; i++){
        int n = (rand() % 1000);
        arr6[i] = n;
        arr16[i] = n;
        arr26[i] = n;
    }
    for(int i = 0; i < 350000; i++){
        int n = (rand() % 1000);
        arr7[i] = n;
        arr17[i] = n;
        arr27[i] = n;
    }
    for(int i = 0; i < 400000; i++){
        int n = (rand() % 1000);
        arr8[i] = n;
        arr18[i] = n;
        arr28[i] = n;
    }
    for(int i = 0; i < 450000; i++){
        int n = (rand() % 1000);
        arr9[i] = n;
        arr19[i] = n;
        arr29[i] = n;
    }
    for(int i = 0; i < 500000; i++){
        int n = (rand() % 1000);
        arr10[i] = n;
        arr20[i] = n;
        arr30[i] = n;
    }

    for(int i = 0 ; i < 10; i++){
        {
            double duration;
            clock_t startTime = clock();
            FIND_MEDIAN_1(arr[i], sizes[i]);
            duration = 1000 * double( clock() - startTime ) / CLOCKS_PER_SEC;
            std::cout << "For algorithm 1 with size " << sizes[i] << ", execution took " << duration << " milliseconds." << std::endl;
        }
        {
            double duration;
            clock_t startTime = clock();
            FIND_MEDIAN_2(arr[10 + i], sizes[i]);
            duration = 1000 * double( clock() - startTime ) / CLOCKS_PER_SEC;
            std::cout << "For algorithm 2 with size " << sizes[i] << ", execution took " << duration << " milliseconds." << std::endl;
        }
        {
            double duration;
            clock_t startTime = clock();
            FIND_MEDIAN_3(arr[20 + i], sizes[i]);
            duration = 1000 * double( clock() - startTime ) / CLOCKS_PER_SEC;
            std::cout << "For algorithm 3 with size " << sizes[i] << ", execution took " << duration << " milliseconds." << std::endl;
        }
        std::cout << std::endl;
    }

    for(int i = 0; i < 30; i++){
        delete[] arr[i];
    }
    delete[] arr;

    return 0;
}
